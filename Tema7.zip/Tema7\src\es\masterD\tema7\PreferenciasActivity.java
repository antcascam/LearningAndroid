package es.masterD.tema7;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.widget.TextView;

public class PreferenciasActivity extends PreferenceActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferences);
	}
	protected void onResume() {
		super.onResume();
		try {
			// Aplicamos las preferencias del usuario al t�tulo
			PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
			SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(this);
			String colorUsuario = p.getString("pref_color", "#000000");
			// Lo aplicamos al titulo
			TextView titulo = (TextView) findViewById(R.string.pref_color_dialogtitle);
			int color = Color.parseColor(colorUsuario);
			titulo.setTextColor(color);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
