package es.masterD.tema7;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class MeminternaActivity extends Activity {
	public String fichero = "misdatos";
	public EditText editor;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.editor);
		editor = (EditText) findViewById(R.id.EditText);
		String texto = loadData();
		editor.setText(texto);
	}

	protected String loadData() {
		FileInputStream fis = null;
		String texto = "";
		try {
			fis = openFileInput(fichero);
			InputStreamReader reader = new InputStreamReader(fis);
			BufferedReader buffreader = new BufferedReader(reader);
			String linea = "";
			while ((linea = buffreader.readLine()) != null) {
				texto += linea + "\n";
			}
		} catch (IOException e) {
			Toast.makeText(this, "Error al leer el fichero", Toast.LENGTH_LONG).show();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return texto;
	}

	/**
	 * onStop()
	 */
	@Override
	protected void onStop() {
		String texto = editor.getText().toString();
		saveData(texto);
		super.onStop();
	}

	/**
	 * Guarda los datos en la memoria interna
	 */
	protected void saveData(String texto) {
		FileOutputStream fos = null;
		try {
			fos = openFileOutput(fichero, Context.MODE_PRIVATE);
			fos.write(texto.getBytes());
		} catch (IOException e) {
			Toast.makeText(this, "Error al guardar el fichero",Toast.LENGTH_LONG).show();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}