/** Automatically generated file. DO NOT MODIFY */
package es.masterD.tema7;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}