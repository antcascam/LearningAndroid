/** Automatically generated file. DO NOT MODIFY */
package com.masterD.practica11;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}