/** Automatically generated file. DO NOT MODIFY */
package com.masterD.practica16;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}