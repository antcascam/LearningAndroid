/** Automatically generated file. DO NOT MODIFY */
package com.masterD.practicas17y18;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}