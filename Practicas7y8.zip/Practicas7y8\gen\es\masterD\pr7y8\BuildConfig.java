/** Automatically generated file. DO NOT MODIFY */
package es.masterD.pr7y8;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}