package es.masterd.rss.parser;

import java.net.URL;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;


import android.content.ContentResolver;
import android.util.Log;

public class RssDownloadHelper {
	private static RssHandler rssHandler;
	private static SAXParser saxParser;
	private static XMLReader xr;
	private static URL url;
	private static InputSource is;
	
	public static void updateRssData(String rssUrl,ContentResolver contentResolver) {
		try {
			url = new URL(rssUrl);
			// Obtenemos el SAXParser
			SAXParserFactory spf = SAXParserFactory.newInstance();
			saxParser = spf.newSAXParser();
		} catch (Exception e) {
			Log.d("updateRssData", "Error al Actualziar los Datos RSS, Obteniendo el SAXParser");
		}
		try {
			// Creamos el Handler
			rssHandler = new RssHandler(contentResolver);
		} catch (Exception e) {
			Log.d("updateRssData", "Error al Actualziar los Datos RSS, Creando el Handler");
		}
		try {
			// Definimos el manejador l�xico
			saxParser.setProperty("http://xml.org/sax/properties/lexical-handler",rssHandler);
		} catch (Exception e) {
				Log.d("updateRssData", "Error al Actualziar los Datos RSS, Definiendo el manejador l�xico");
		}
		try {
			// Obtenemos el Reader
			xr = saxParser.getXMLReader();
			xr.setContentHandler(rssHandler);
		} catch (Exception e) {
				Log.d("updateRssData", "Error al Actualziar los Datos RSS, Obteneniendo el Reader");
		}
		try {
			// Parseamos el contenido
			is = new InputSource(url.openStream());
		} catch (Exception e) {
			Log.d("updateRssData", "Error al Actualziar los Datos RSS, Pasando la url");
		}
		try {
			is.setEncoding("utf-8");
		} catch (Exception e) {
		Log.d("updateRssData", "Error al Actualziar los Datos RSS, Haciendo el enconding");
		}
		try {
			xr.parse(is);
		} catch (Exception e) {
			Log.d("updateRssData", "Error al Actualziar los Datos RSS, Parseando el contenido");
		}
		// El parseo ha concluido
	}
}