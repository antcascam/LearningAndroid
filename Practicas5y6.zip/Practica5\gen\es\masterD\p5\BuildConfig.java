/** Automatically generated file. DO NOT MODIFY */
package es.masterD.p5;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}